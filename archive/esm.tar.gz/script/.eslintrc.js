"use strict"

module.exports = {
  rules: {
    strict: "off"
  }
}
