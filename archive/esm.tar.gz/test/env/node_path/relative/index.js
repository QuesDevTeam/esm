"use strict"

module.exports = "outside dot"
