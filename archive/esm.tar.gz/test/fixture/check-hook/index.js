import { log } from "console"

log("check-hook:true")
