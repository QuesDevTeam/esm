"use strict"

module.exports = require("_http_agent")
