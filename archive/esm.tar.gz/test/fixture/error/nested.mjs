if (true) {
  import"nested"
}
