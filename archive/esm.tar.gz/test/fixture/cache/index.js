"use strict"

require = require("../../../")(module)
require("./main.mjs")
