import { log } from "console"
import "./a.mjs"

log("cache:true")
