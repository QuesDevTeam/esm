"use strict"

;(0, eval)("import.meta")
