module.exports = (0, eval)(`
  "use strict"
  import("path")
  ;(function () {
    return this
  })()
`)
