module.exports = eval(`
  "use strict"
  import("path")
  ;(function () {
    return this
  })()
`)
