"use strict"

eval("import.meta")
