export { a } from "./abc-ambiguous.mjs"
