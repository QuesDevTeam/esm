export { a } from "./abc-ambiguous.js"
