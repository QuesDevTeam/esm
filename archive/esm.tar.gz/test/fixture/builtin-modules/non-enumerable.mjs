import { log } from "console"
import { promises } from "fs"

log("non-enumerable:false")
