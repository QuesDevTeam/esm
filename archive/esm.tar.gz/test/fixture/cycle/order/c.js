const tracker = require("./tracker.js")

require("./b.js")
tracker.push("c")
module.exports = {}
require("./d.js")
