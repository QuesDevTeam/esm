const tracker = require("./tracker.js")

require("./a.js")
tracker.push("b")
module.exports = {}
require("./c.js")
