const tracker = require("./tracker.js")

require("./c.js")
tracker.push("d")
module.exports = {}
