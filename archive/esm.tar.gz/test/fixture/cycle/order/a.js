const tracker = require("./tracker.js")

tracker.push("a")
module.exports = {}
require("./b.js")
