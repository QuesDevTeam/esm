import { a } from "./a.mjs"

export default class B {
  b() {
    a()
  }
}
