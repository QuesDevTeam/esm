import { b } from "./b.wasm"

export default b(1, 2)

export function a(x, y) {
  return x + y
}
