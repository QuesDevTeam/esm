"use strict"

module.exports = import("./a.js")
