export default import("./a.mjs")
