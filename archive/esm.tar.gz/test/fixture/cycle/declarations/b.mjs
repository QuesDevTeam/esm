import { a } from "./a.mjs"

function b() {
  return true
}

export default a()
export { b }
