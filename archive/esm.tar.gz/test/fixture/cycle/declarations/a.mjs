import { b } from "./b.mjs"

function a() {
  return b()
}

export { a }
