import * as aNs from "./a.mjs"
import * as cNs from "./c.mjs"

if (true) {
  aNs
  cNs.c
}
