import { A } from "./a.mjs"

export class B {
  static A() {
    return A
  }
}
