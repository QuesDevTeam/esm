import "./b.mjs"

export const a = "a"
