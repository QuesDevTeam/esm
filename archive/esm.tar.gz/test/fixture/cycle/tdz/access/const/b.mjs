import { a } from "./a.mjs"

if (true) {
  a
}
