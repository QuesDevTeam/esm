import "./b.mjs"

export let a = "a"
