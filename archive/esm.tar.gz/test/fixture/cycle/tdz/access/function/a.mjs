import "./b.mjs"

export function a() {}
