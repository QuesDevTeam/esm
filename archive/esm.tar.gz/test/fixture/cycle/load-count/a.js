"use strict"

require("../../load-count.js")
require("./a.js")
