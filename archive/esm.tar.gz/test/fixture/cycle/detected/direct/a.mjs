
export { x2 as x1 } from "./b.mjs"
