
export { x1 as x2 } from "./a.mjs"
