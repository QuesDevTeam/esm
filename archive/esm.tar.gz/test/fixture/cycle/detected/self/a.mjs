export { x } from "./a.mjs"
