function a() {
  return "a"
}

import { b } from "./b.mjs"

export default b()
export { a }
