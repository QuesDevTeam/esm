import { a } from "./a.mjs"

export function b() {
  return a()
}
