export * from "./b.mjs"
export const a = "a"
