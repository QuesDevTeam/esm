export * from "./a.mjs"
export const b = "b"
