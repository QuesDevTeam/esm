import "./b.mjs"
import * as ns from "./c.mjs"

export function getNS() {
  return ns
}
