"use strict"

exports.d = "d"
