"use strict"

exports.f = "f"
