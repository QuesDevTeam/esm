import "./b.js"
import * as ns from "./c.js"

export function getNS() {
  return ns
}
