const pnp = {}

export default pnp
