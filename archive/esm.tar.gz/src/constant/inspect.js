const INSPECT = {
  PROXY_PREFIX: "Proxy ["
}

export default INSPECT
