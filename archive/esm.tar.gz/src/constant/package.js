/* eslint-disable sort-keys */
const PACKAGE = {
  MODE_STRICT: 1,
  MODE_AUTO: 2,
  MODE_ALL: 3,
  RANGE_ALL: "*"
}

export default PACKAGE
