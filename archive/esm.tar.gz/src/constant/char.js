const CHAR = {
  ZERO_WIDTH_JOINER: "\u200D"
}

export default CHAR
