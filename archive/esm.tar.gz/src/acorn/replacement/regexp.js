class RegExpValidationState {
  reset() {}
}

// eslint-disable-next-line import/prefer-default-export
export { RegExpValidationState }
