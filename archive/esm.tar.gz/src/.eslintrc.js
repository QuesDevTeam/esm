"use strict"

module.exports = {
  rules: {
    "node/no-unsupported-features": "off"
  }
}
