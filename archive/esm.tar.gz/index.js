/* eslint strict: off, node/no-unsupported-features: ["error", { version: 6 }] */
"use strict"

module.exports = require("./esm.js")
