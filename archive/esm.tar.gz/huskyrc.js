"use strict"

module.exports = {
  hooks: {
    precommit: "npm run lint"
  }
}
